
function lonin()
{
    var log_Name = document.getElementById("input_box").value;

    

    localStorage.setItem("Lonin_Id",log_Name);


   window.location="chatweb.html";
}

