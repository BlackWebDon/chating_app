function logout()
{
    window.location="index.html";
}

var room_Id = localStorage.getItem("room name");
document.getElementById("RoomIdInfo").innerHTML = "#"+ room_Id;

var username = localStorage.getItem("Lonin_Id");
document.getElementById("username").innerHTML=username;